import { useState } from "react"
import AuthUser from "./AuthUser";



export default function Login() {
    const { http, setToken } = AuthUser();
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const submitForm = () => {
        http.post('/login', { email: email, password: password }).then((res) => {
            setToken(res.data.user,res.data.authorisation.token);
            // setToken(res.data.user, res.data.access_token);
        })
    }

    return (

        <div className="container row justify-content-center pt-5">
            <div className="col-md-6">
                <form>
              
                    <div className="form-group">
                        <label >Email address</label>
                        <input type="email" className="form-control" name="email" id="email" aria-describedby="emailHelp" placeholder="Enter email" onChange={e => setEmail(e.target.value)} />

                    </div>
                    <div className="form-group mt-3 mb-3">
                        <label>Password</label>
                        <input type="password" className="form-control" name="password" id="password" placeholder="Password" onChange={e => setPassword(e.target.value)} />
                    </div>

                    <button type="button" className="btn btn-primary" onClick={submitForm}>Login</button>
                </form>

            </div>
        </div>

    )
}